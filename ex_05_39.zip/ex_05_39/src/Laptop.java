class Laptop {
    private String name;
    public Laptop()
    {

    }
    public Laptop(String name)
    {
        this.name = name;
    }
    public String getName()
    {
        return name;
    }
}
